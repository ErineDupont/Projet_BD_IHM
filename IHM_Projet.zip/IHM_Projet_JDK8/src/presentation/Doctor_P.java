package presentation;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class Doctor_P extends GridPane {
	private Label rppsLabel;
	private Label lastNameLabel;
	private Label firstNameLabel;
	private Label addressLabel;
	private Label phoneNumberLabel;
	private Label specialityLabel;
	
	public Doctor_P () {
		Label rppsTitle = new Label("rpps : ");
		Label lastNameTitle = new Label("Last Name : ");
		Label firstNameTitle = new Label("First Name : ");
		Label addressTitle = new Label("Address : ");
		Label phoneNumberTitle = new Label("Phone Number : ");
		Label specialityTitle = new Label("Speciality : ");
		rppsLabel = new Label();
		lastNameLabel = new Label();
		firstNameLabel = new Label();
		addressLabel = new Label();
		phoneNumberLabel = new Label();
		specialityLabel = new Label();
		addRow(0, lastNameTitle, lastNameLabel);
		addRow(1, firstNameTitle, firstNameLabel);
		addRow(2, rppsTitle, rppsLabel);
		addRow(3, phoneNumberTitle, phoneNumberLabel);
		addRow(4, addressTitle, addressLabel);
		addRow(5, specialityTitle, specialityLabel);
		}
	
	public void update (String lastName, String firstName, String rpps, String phoneNumber, String address, String speciality) {
		lastNameLabel.setText(lastName);
		firstNameLabel.setText(firstName);
		rppsLabel.setText(rpps);
		phoneNumberLabel.setText(phoneNumber);
		addressLabel.setText(address);
		specialityLabel.setText(speciality);
	}
}
