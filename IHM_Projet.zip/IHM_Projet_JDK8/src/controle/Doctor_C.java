package controle;

import metier.Doctor;
import presentation.Doctor_P;

public class Doctor_C {

	//-------------------------------------------------------------------------------------
	// classe de controle d'un docteur : elle fait le lien entre le métier et la présentation
	//-------------------------------------------------------------------------------------

	private Doctor_P presentation ;
	private Doctor abstraction ; // pas absolument indispensable ici, mais bonne habitude à prendre

	//-------------------------------------------------------------------------------------
	// constructeur : crée simplement un composant de présentation prêt à l'emploi
	//-------------------------------------------------------------------------------------
	public Doctor_C () {
		presentation = new Doctor_P () ;
	}

	//-------------------------------------------------------------------------------------
	// mise à jour de l'abstraction : transforme les données métier en types de base à transmettre à la présentation
	// et mise à jour de la présentation avec ces données transformées
	//-------------------------------------------------------------------------------------
	public void setAbstraction (Doctor doctor) {
		abstraction = doctor ; 
		String rpps = abstraction.getRpps() ;
		String lastName = abstraction.getLastName();
		String firstName = abstraction.getFirstName();
		String address = abstraction.getAddress();
		String phoneNumber = abstraction.getPhoneNumber();
		String speciality = abstraction.getSpeciality();
		presentation.update (lastName, firstName, rpps, phoneNumber, address, speciality) ;
	}

	public Doctor_P getPresentation () {
		return presentation ;
	}

}
