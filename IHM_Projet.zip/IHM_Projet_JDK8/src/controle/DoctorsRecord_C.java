package controle;

import java.util.ArrayList;
import java.util.List;

import metier.Doctor;
import metier.MedicalRecord;
import metier.Patient;
import presentation.DoctorsRecord_P;
import presentation.PatientsRecord_P;

//=====================================================================================
//classe de controle de la liste des docteurs
//=====================================================================================

public class DoctorsRecord_C {

	private Doctor currentDoctor ;
	private Doctor_C currentDoctor_C ;
	private Doctor_ActiveC currentDoctor_ActiveC ;
	private DoctorsRecord_P presentation ;
	private MedicalRecord abstraction ;

	public DoctorsRecord_C (MedicalRecord abstraction, DoctorsRecord_P presentation) {
		this.abstraction = abstraction ;
		this.presentation = presentation ;
		// dans cette version on va minimiser les créations de composans de contrôle :
		// on les crée ici et on mettra à jour leurs abstractions quand ce sera nécessaire 
		currentDoctor_C = new Doctor_C () ;
		currentDoctor_ActiveC = new Doctor_ActiveC (this) ;
		presentation.initialize (this, getDoctorsNames ()) ;
		presentation.disableActionOnSelection () ;
	}

	//-------------------------------------------------------------------------------------
	// méthode utilitaire pour construire une liste de String à partir d'une liste de Doctors
	//-------------------------------------------------------------------------------------

	private List<String> getDoctorsNames () {
		List<String> doctors = new ArrayList<String> () ;
		for (Doctor doctor : abstraction.getDoctors ()) {
			doctors.add (doctor.getLastName () + " " + doctor.getFirstName ()) ;
		}
		return doctors ;
	}

	//=====================================================================================
	// méthodes appelées par la présentation suite aux interactions de l'utilisateur
	//=====================================================================================

	//-------------------------------------------------------------------------------------
	// sélection d'un docteur : on récupère l'indice du docteur dans notre ArrayList de doctors
	//-------------------------------------------------------------------------------------

	public void selectDoctor (int selectedIndex) {
		// on note quel est le doctor associé à l'index de la présentation
		currentDoctor = abstraction.getDoctors ().get (selectedIndex) ;
		// on met à jour la présentation en demandant l'affichage de l'aperçu du patient
		currentDoctor_C.setAbstraction (currentDoctor);
		presentation.selectDoctor (currentDoctor_C.getPresentation ()) ;
		// et en activant les moyens d'édition et de destruction du patient sélectionné
		presentation.enableActionOnSelection () ;
		// si quelqu'un est rattaché à ce patient on empêche quand même de le détruire
		if (abstraction.somebodyIsPatientOfThisDoctor (currentDoctor)) {
			presentation.disableDeleteOnSelection () ;
		}
	}

	//-------------------------------------------------------------------------------------
	// désélection d'un docteur
	//-------------------------------------------------------------------------------------

	public void selectNoDoctor () {
		currentDoctor = null ;
		// il n'y a plus de docteur sélectionné, il faut faire disparaitre l'aperçu et désactiver les boutons d'actions 
		presentation.selectNoDoctor () ;
		presentation.disableActionOnSelection () ;
	}

	//-------------------------------------------------------------------------------------
	// suppression d'un patient dans la liste : on l'enlève dans les 2 structures pour garder la correspondance des indices
	//-------------------------------------------------------------------------------------

	public void deleteDoctor () {
		abstraction.deleteDoctor (currentDoctor) ;
		presentation.initialize (this, getDoctorsNames ()) ;
		presentation.disableActionOnSelection () ;
	}

	//-------------------------------------------------------------------------------------
	// édition du patient courant : on va appeler un dialogue et y mettre une présentation active de patient
	//-------------------------------------------------------------------------------------

	public void editDoctor () {
		currentDoctor_ActiveC.setAbstraction (currentDoctor) ;
		currentDoctor_ActiveC.activate () ;      
	}

	//-------------------------------------------------------------------------------------
	// création d'un patient : on va appeler un dialogue et y mettre une nouvelle présentation active de patient
	//-------------------------------------------------------------------------------------

	public void createDoctor () {
		Doctor doctor = new Doctor () ;
		currentDoctor_ActiveC.setAbstraction (doctor) ;
		currentDoctor_ActiveC.activate () ;
	}


	//-------------------------------------------------------------------------------------
	// mise à jour des caractéristiques d'un patient : c'est peut-être un nouveau patient...
	//-------------------------------------------------------------------------------------

	public void updateDoctor (Doctor_ActiveC doctorToUpdate) {
		// si le patient est connu, on le met à jour
		if (abstraction.containsDoctor (doctorToUpdate.getAbstraction ())) {
			abstraction.updateDoctor (doctorToUpdate.getAbstraction ()) ;
		} else {
			// sinon on l'ajoute...
			abstraction.addDoctor (doctorToUpdate.getAbstraction ()) ;
		}
		// ensuite on réinitialise la présentation pour tenir compte des éventuelles modifications
		presentation.initialize (this, getDoctorsNames ()) ;
		currentDoctor_C.setAbstraction (doctorToUpdate.getAbstraction ());
		presentation.selectDoctor (currentDoctor_C.getPresentation ()) ;
		presentation.selectDoctor (doctorToUpdate.toString ()) ;
	}

	//=====================================================================================
	// méthodes relai vers l'abstraction
	//=====================================================================================

	public boolean somebodyIsPatientOfThisDoctor (Doctor doctor) {
		return (abstraction.somebodyIsPatientOfThisDoctor (doctor)) ;
	}


	public List<Patient> getPatients () {
		return abstraction.getPatients () ;
	}

	public List<Doctor> getDoctors () {
		return abstraction.getDoctors () ;
	}

	//=====================================================================================
	// méthode relai vers la présentation
	//=====================================================================================

	public DoctorsRecord_P getPresentation () {
		return presentation ;
	}

}
