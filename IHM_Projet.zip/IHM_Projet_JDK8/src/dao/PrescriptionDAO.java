package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import actions.Consultation;
import actions.Prescription;
import metier.Patient;

/**
 * DAO associé aux prescriptions.
 * Assure les fonctionnalités CRUD : Create, Retrieve, Update et Delete.
 */

public class PrescriptionDAO {
	// -----------------------------------------------------------------------------
	// CREATE
	// -----------------------------------------------------------------------------

	/**
	 * Création d'une nouvelle prescription dans le stockage.
	 * @param prescriptionID
	 * @param medicament
	 * @param doctorID
	 * @param patientID
	 * @param date
	 * @param duration
	 * @param posology
	 * @param modalities
	 * @throws MedicalRecordException
	 */

	public static Prescription create (String medicament, 
			int doctorID, int patientID, Date date, 
			int duration, float posology, String modalities) throws MedicalRecordException {
		try {
			String sql = "insert into prescription values (DEFAULT,?, ?, ?, ?, ?, ?, ?)" ;
			Connection conn = DBUtil.getConnection () ;

			// Insertion de la nouvelle prescription
			PreparedStatement ps1 = conn.prepareStatement (sql) ;
			ps1.setString (1, medicament) ;
			ps1.setInt (2, doctorID) ;
			ps1.setInt (3, patientID);
			ps1.setDate (4, date);
			ps1.setInt (5, duration);
			ps1.setFloat(6, posology);
			ps1.setString(7, modalities);
			ps1.executeUpdate () ;
			ps1.close () ;
			
			// Récupération de l'ID de la nouvelle prescription
			String sql2 = "select currval('prescription_prescription_id_seq') as prescription_id";
			PreparedStatement ps2 = conn.prepareStatement (sql2);
			ResultSet rs = ps2.executeQuery();
			rs.next();
			int prescriptionID = rs.getInt("prescription_id");

			conn.close () ;
			return new Prescription (prescriptionID, medicament, doctorID, 
					patientID, date, duration, posology, modalities) ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static Prescription create (Prescription prescription) throws MedicalRecordException {
		return create (prescription.getMedicament(), prescription.getDoctorID(), 
				prescription.getPatientID(), prescription.getDate(), prescription.getDuration(), 
				prescription.getPosology(), prescription.getModalities()) ;
	}

	// -----------------------------------------------------------------------------
	// RETRIEVE
	// -----------------------------------------------------------------------------

	/**
	 * Recherche d'une prescription par son ID
	 * 
	 * @param prescriptionID
	 * @return
	 * @throws MedicalRecordException
	 */
	public static Prescription find (int prescriptionID) throws MedicalRecordException {
		try {
			Prescription prescription = null ;
			String sql = "select * from prescription where prescription_id=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, prescriptionID) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				prescription = new Prescription (rs.getInt("prescription_id"), 
						rs.getString("medicament"), rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getInt("duree"), 
						rs.getFloat("posologie"), rs.getString("modalites")) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return prescription ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}
	
	public static Prescription find (Prescription prescription) throws MedicalRecordException {
		return find(prescription.getPrescriptionID());
	}

	/** Recherche de tous les médicaments prescrits à un patient
	 * 
	 * @param patient
	 * @return
	 * @throws MedicalRecordException
	 */
	public static Prescription findMedicines (Patient patient) throws MedicalRecordException {
		try {
			Prescription prescription = null ;
			String sql = "select * from prescription where patient=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, patient.getPatientID()) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				prescription = new Prescription (rs.getInt("prescription_id"), 
						rs.getString("medicament"), rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getInt("duree"), 
						rs.getFloat("posologie"), rs.getString("modalites")) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return prescription ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}
	
	/** Recherche de tous les patients pour lesquels le médicament est prescrit
	 * 
	 * @param medicament
	 * @return
	 * @throws MedicalRecordException
	 */
	public static Prescription findPatients(String medicament) throws MedicalRecordException {
		try {
			Prescription prescription = null ;
			String sql = "select * from prescription where medicament=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setString (1, medicament) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				prescription = new Prescription (rs.getInt("prescription_id"), 
						rs.getString("medicament"), rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getInt("duree"), 
						rs.getFloat("posologie"), rs.getString("modalites")) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return prescription ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}
	
	/** Recherche de toutes les prescriptions
	 * 
	 * @return
	 * @throws MedicalRecordException
	 */
	public static List<Prescription> findAll () throws MedicalRecordException {
		try {
			List<Prescription> prescriptions = new ArrayList<> () ;
			String sql = "select * from prescription order by patient" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				Prescription prescription = new Prescription (rs.getInt("prescription_id"), 
						rs.getString("medicament"), rs.getInt("medecin"), rs.getInt ("patient"),
						rs.getDate ("date_visite"), rs.getInt("duree"), rs.getFloat ("posologie"),
						rs.getString("modalites"));
				prescriptions.add(prescription);
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return prescriptions;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}
	// -----------------------------------------------------------------------------
	// UPDATE
	// -----------------------------------------------------------------------------

	/**
	 * Mise à jour dans le stockage des informations d'une prescription.
	 * 
	 * @param prescriptionID
	 * @param medicament
	 * @param doctorID
	 * @param patientID
	 * @param date
	 * @param duration
	 * @param posology
	 * @param modalities
	 */
	private static Prescription update (int prescriptionID, String medicament, 
			int doctorID, int patientID, Date date, int duration,
			float posology, String modalities) throws MedicalRecordException {
		try {
			String sql = "update prescription set medicament=?, medecin=?, patient=?, date_visite=?, duree=?, posologie=?, modalites=? where prescription_id=?";
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setString (1, medicament) ;
			ps.setInt(2, doctorID);
			ps.setInt(3, patientID);
			ps.setDate(4, date);
			ps.setInt(5, duration);
			ps.setFloat(6, posology);
			ps.setString(7, modalities);
			ps.setInt(8, prescriptionID);
			ps.executeUpdate();
			ps.close () ;
			conn.close () ;
			return new Prescription (prescriptionID, medicament, doctorID, patientID, date, duration, posology, modalities) ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static Prescription update (int prescriptionID, String medicament, Consultation consultation, 
			int duration, float posology, String modalities) throws MedicalRecordException {
		return update (prescriptionID, medicament, consultation.getDoctorID(),consultation.getPatientID(), 
				consultation.getDate(), duration, posology, modalities) ;
	}

	// -----------------------------------------------------------------------------
	// DELETE
	// -----------------------------------------------------------------------------

	public static void delete (int prescriptionID) throws MedicalRecordException {
		try {
			String sql = "delete from prescription where prescription_id=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, prescriptionID) ;
			ps.executeUpdate () ;
			ps.close () ;
			conn.close () ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static void delete (Prescription prescription) throws MedicalRecordException {
		delete (prescription.getPrescriptionID()) ;
	}


}
