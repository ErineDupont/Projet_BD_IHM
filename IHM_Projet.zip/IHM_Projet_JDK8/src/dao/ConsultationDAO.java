package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import actions.Consultation;
import metier.Doctor;
import metier.Patient;

/**
 * DAO associé aux consultations.
 * Assure les fonctionnalités CRUD : Create, Retrieve, Update et Delete.
 */
public class ConsultationDAO {

	// -----------------------------------------------------------------------------
	// CREATE
	// -----------------------------------------------------------------------------

	/**
	 * Création d'une nouvelle consultation dans le stockage.
	 * 
	 * @param doctor
	 * @param patient
	 * @param date
	 * @param prix
	 * @throws MedicalRecordException
	 */

	public static Consultation create (int doctorID, int patientID, Date date, 
			float prix) throws MedicalRecordException {
		try {
			String sql = "insert into visite values (?, ?, ?, ?)" ;
			Connection conn = DBUtil.getConnection () ;

			// Insertion de la nouvelle consultation
			PreparedStatement ps1 = conn.prepareStatement (sql) ;
			ps1.setInt (1, doctorID) ;
			ps1.setInt (2, patientID) ;
			ps1.setDate(3, date);
			ps1.setFloat (4, prix) ;
			ps1.executeUpdate () ;
			ps1.close () ;

			conn.close () ;
			return new Consultation (doctorID, patientID, date, prix) ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static Consultation create (Consultation consultation) throws MedicalRecordException {
		return create (consultation.getDoctorID(), consultation.getPatientID(), 
				consultation.getDate(), consultation.getPrix()) ;
	}

	// -----------------------------------------------------------------------------
	// RETRIEVE
	// -----------------------------------------------------------------------------

	/**
	 * Recherche d'une consultation par la clé <Médecin, Patient, Date>.
	 * 
	 * @param doctor
	 * @param patient
	 * @param date
	 * @return
	 * @throws MedicalRecordException
	 */
	public static Consultation find (Doctor doctor, Patient patient, Date date) throws MedicalRecordException {
		try {
			Consultation consultation = null ;
			String sql = "select * from visite where medecin=? and patient=? and date_visite=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, doctor.getDoctorID()) ;
			ps.setInt(2, patient.getPatientID());
			ps.setDate(3, date);
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				consultation = new Consultation (rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getFloat("prix")) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return consultation ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	/** Cette fonction permet de retrouver toutes les consultations d'un patient, passées et futures
	 * à partir de son ID
	 * @param patientID
	 * @return Liste des consultations
	 * @throws MedicalRecordException
	 */
	public static List<Consultation> findPatientsConsultations (int patientID) throws MedicalRecordException {
		try {
			List<Consultation> consultations = new ArrayList<> () ;
			String sql = "select * from visite where patient=? order by date_visite" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, patientID) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				Consultation consultation = new Consultation (rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getFloat("prix")) ;
				consultations.add (consultation) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return consultations ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static List<Consultation> findPatientsConsultations (Patient patient) throws MedicalRecordException {
		return findPatientsConsultations(patient.getPatientID());
	}

	/** Cette fonction permet de retrouver toutes les consultations d'un docteur, passées et futures
	 * à partir de son ID
	 * @param doctorID
	 * @return Liste des consultations
	 * @throws MedicalRecordException
	 */
	public static List<Consultation> findDoctorsConsultations (int doctorID) throws MedicalRecordException {
		try {
			List<Consultation> consultations = new ArrayList<> () ;
			String sql = "select * from visite where medecin=? order by date_visite" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, doctorID) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				Consultation consultation = new Consultation (rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getFloat("prix")) ;
				consultations.add (consultation) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return consultations ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static List<Consultation> findDoctorsConsultations (Doctor doctor) throws MedicalRecordException {
		return findDoctorsConsultations(doctor.getDoctorID());
	}

	/** Cette fonction renvoie toutes les consultations entre un médecin et un docteur
	 * @param patientID
	 * @param doctor ID
	 * @return liste de consultations
	 */
	public static List<Consultation> findDates (int doctorID, int patientID) throws MedicalRecordException {
		try {
			List<Consultation> consultations = new ArrayList<> () ;
			String sql = "select * from visite where patient=? and medecin=? order by date_visite" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, patientID) ;
			ps.setInt(2, doctorID);
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				Consultation consultation = new Consultation (rs.getInt("medecin"), 
						rs.getInt("patient"), rs.getDate("date_visite"), rs.getFloat("prix")) ;
				consultations.add (consultation) ;
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return consultations ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static List<Consultation> findDates (Doctor doctor, Patient patient) throws MedicalRecordException {
		return findDates(doctor.getDoctorID(), patient.getPatientID());
	}

	public static List<Consultation> findAll () throws MedicalRecordException {
		try {
			List<Consultation> consultations = new ArrayList<> () ;
			String sql = "select * from visite order by date_visite" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ResultSet rs = ps.executeQuery () ;
			while (rs.next ()) {
				Consultation consultation = new Consultation (rs.getInt("medecin"),
						rs.getInt ("patient"),
						rs.getDate ("date_visite"),
						rs.getFloat ("prix"));
				consultations.add(consultation);
			}
			rs.close () ;
			ps.close () ;
			conn.close () ;
			return consultations ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}
	// -----------------------------------------------------------------------------
	// UPDATE
	// -----------------------------------------------------------------------------

	/**
	 * Mise à jour dans le stockage des informations d'une consultation.
	 * 
	 * @param doctorID
	 * @param patientID
	 * @param date
	 * @param prix
	 */
	private static Consultation update (int doctorID, int patientID, Date date, float prix) throws MedicalRecordException {
		try {
			String sql = "update visite set prix=? where medecin=? and patient=? and date_visite=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setFloat (1, prix) ;
			ps.setInt(2, doctorID);
			ps.setInt(3, patientID);
			ps.setDate(4, date);
			ps.executeUpdate () ;
			ps.close () ;
			conn.close () ;
			return new Consultation (doctorID, patientID, date, prix) ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static Consultation update (Doctor doctor, Patient patient, Date date, float prix) throws MedicalRecordException {
		return update (doctor.getDoctorID(), patient.getPatientID(), date, prix) ;
	}

	// -----------------------------------------------------------------------------
	// DELETE
	// -----------------------------------------------------------------------------

	private static void delete (int doctorID, int patientID, Date date) throws MedicalRecordException {
		try {
			String sql = "delete from visite where medecin=? and patient=? and date_visite=?" ;
			Connection conn = DBUtil.getConnection () ;
			PreparedStatement ps = conn.prepareStatement (sql) ;
			ps.setInt (1, doctorID) ;
			ps.setInt(2, patientID);
			ps.setDate(3, date);
			ps.executeUpdate () ;
			ps.close () ;
			conn.close () ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static void delete (Consultation consultation) throws MedicalRecordException {
		delete (consultation.getDoctorID(), consultation.getPatientID(), 
				consultation.getDate()) ;
	}

}