package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import actions.Consultation;

/**
 * DAO associé aux consultations.
 * Assure les fonctionnalités CRUD : Create, Retrieve, Update et Delete.
 */

public class MedicalActDAO {
	// -----------------------------------------------------------------------------
	// CREATE
	// -----------------------------------------------------------------------------

	/** Création d'un nouvel acte médical
	 * @param acteID
	 * @param doctorID
	 * @param patientID
	 * @param type
	 * @param personnel
	 */
	
	public static Consultation create (int doctorID, int patientID, Date date, 
			float prix) throws MedicalRecordException {
		try {
			String sql = "insert into visite values (?, ?, ?, ?)" ;
			Connection conn = DBUtil.getConnection () ;

			// Insertion de la nouvelle consultation
			PreparedStatement ps1 = conn.prepareStatement (sql) ;
			ps1.setInt (1, doctorID) ;
			ps1.setInt (2, patientID) ;
			ps1.setDate(3, date);
			ps1.setFloat (4, prix) ;
			ps1.executeUpdate () ;
			ps1.close () ;

			conn.close () ;
			return new Consultation (doctorID, patientID, date, prix) ;
		} catch (SQLException sqle) {
			throw new MedicalRecordException (sqle.getMessage ()) ;
		}
	}

	public static Consultation create (Consultation consultation) throws MedicalRecordException {
		return create (consultation.getDoctorID(), consultation.getPatientID(), 
				consultation.getDate(), consultation.getPrix()) ;
	}

}
