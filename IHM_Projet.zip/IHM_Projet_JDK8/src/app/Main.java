package app ;

import java.sql.Date;

import actions.Consultation;
import actions.Prescription;
import controle.DoctorsRecord_C;
import controle.PatientsRecord_C;
import dao.ConsultationDAO;
import dao.DBUtil ;
import dao.DoctorDAO;
import dao.PatientDAO;
import dao.PrescriptionDAO;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TabPane ;
import javafx.stage.Stage;
import metier.Doctor;
import metier.MedicalRecord;
import metier.Patient;
import presentation.DoctorsRecord_P;
import presentation.PatientsRecord_P ;

public class Main extends Application {

	public static void main (String [] args) {
		DBUtil.setBase ("soins") ;
		DBUtil.setHost ("localhost") ;
		DBUtil.setNumPort ("5432") ;
		DBUtil.setUsername ("user") ;
		DBUtil.setPassword ("usr") ;
		launch (args) ;
	}

	@Override
	public void start (Stage primaryStage) throws Exception {
		PatientsRecord_C patientsRecord_C = new PatientsRecord_C (new MedicalRecord (), new PatientsRecord_P (primaryStage)) ;
		DoctorsRecord_C doctorsRecord_C = new DoctorsRecord_C (new MedicalRecord(), new DoctorsRecord_P(primaryStage));

		// container principal de notre IMH : un TabPane pour accueillir des onglets
		// idéalement il faudrait faire une classe nommée MedicalRecord chargée de l'ensemble du projet 
		TabPane peopleTabPane = new TabPane () ;
		// ajout des onglets Patients et Docteurs dans le TabPane
		peopleTabPane.getTabs ().addAll (patientsRecord_C.getPresentation (), doctorsRecord_C.getPresentation()) ;
		// association de la scène contenant le container principal en tant que scène de l'application
		primaryStage.setScene (new Scene (peopleTabPane)) ;
		primaryStage.setTitle ("Projet - BD IHM") ;
		primaryStage.setWidth (600) ;
		primaryStage.show () ;

		//------------------------------------------------------------------------------------------------------------
		//Tests de DAOs
		//------------------------------------------------------------------------------------------------------------
		try{
			Doctor doctorTest1 = new Doctor(13,"1335965", "Colin de Verdière","Albane","Nantes","06624","généraliste");
			Patient patientTest1 = new Patient(16,"131526","Female","28/12/1998", "Dupont", "Erine", null, doctorTest1);
			Date dateTest1 = new Date (119, 04, 06); //yyyy - 1900, mm - 1, jj
			Date dateTest2 = new Date (119, 04, 07);
			Consultation consultationTest1 = new Consultation (doctorTest1, patientTest1, dateTest1, 50f);
			Consultation consultationTest2 = new Consultation (doctorTest1, patientTest1, dateTest2, 75f);
			Prescription prescriptionTest1 = new Prescription (4, "ventoline", consultationTest1, 90, 8, "pour le fun");

			//DoctorDAO.create (doctorTest1);
			//PatientDAO.create(patientTest1);

			//DoctorDAO.update(13,"1335965", "Colin de Verdière","Albane","Nantes","06624","généraliste");
			//System.out.println (DoctorDAO.find(doctorTest1));
			//System.out.println (DoctorDAO.findAll()) ;

			//DoctorDAO.create (14,"26582826","Atan","Charles","Partout","06060606","Tout")
			//DoctorDAO.delete (14);

			//ConsultationDAO.create (consultationTest1);
			//ConsultationDAO.create (consultationTest2);
			//ConsultationDAO.update (doctorTest1, patientTest1, dateTest1,60f);
			//System.out.println (ConsultationDAO.find(doctorTest1,patientTest1,dateTest1));
			//System.out.println (ConsultationDAO.findDates (doctorTest1, patientTest1)) ;
			//System.out.println (ConsultationDAO.findPatientsConsultations (patientTest1)) ;
			//System.out.println (ConsultationDAO.findDoctorsConsultations (doctorTest1)) ;
			//System.out.println (ConsultationDAO.findAll ()) ;

			//ConsultationDAO.delete (consultationTest2);

			//PrescriptionDAO.create (prescriptionTest1);
			//PrescriptionDAO.update (4, "ventoline", consultationTest1, 90, 8, "pour le lulz");

			//System.out.println (PrescriptionDAO.find (prescriptionTest1));
			//System.out.println (PrescriptionDAO.findMedicines (patientTest1)) ;
			//System.out.println (PrescriptionDAO.findPatients ("ventoline")) ;
			//System.out.println (PrescriptionDAO.findAll ()) ;

			//PrescriptionDAO.delete (4);
		}
		catch (Exception MedicalRecordException) {
			System.out.println (MedicalRecordException.getMessage ()) ;
		}
		
	}
}