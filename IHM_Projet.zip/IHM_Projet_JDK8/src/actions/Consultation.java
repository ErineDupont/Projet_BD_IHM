package actions;

import java.sql.Date;

import metier.Doctor;
import metier.Patient;

/** Représentation informatique d'une consultation
 */

public class Consultation {
	
	private int doctorID;
	private int patientID;
	private Date date;
	private float prix;
	
	public Consultation (int doctorID, int patientID, Date date, float prix) 
	{
		this.doctorID = doctorID;
		this.patientID = patientID;
		this.date = date;
		this.prix = prix;
	}
	
	public Consultation (Doctor doctor, Patient patient, Date date, float prix)
	{
		this.doctorID = doctor.getDoctorID();
		this.patientID = patient.getPatientID();
		this.date = date;
		this.prix = prix;
	}
	
	public int getDoctorID() { return doctorID;	}
	public int getPatientID() { return patientID;	}
	public Date getDate() { return date;	}
	public float getPrix() {return prix;	}
	
	public void setDoctorID(int doctorID) { this.doctorID = doctorID;	}
	public void setPatient(int patientID) { this.patientID = patientID;	}
	public void setDate(Date date) { this.date = date;	}
	public void setPrix (float prix) {
		if (prix <= 0) {
			this.prix = 0;
		} else {
			this.prix = prix;
		}
	}

	@Override
	public String toString() {
		return "Consultation [doctorID=" + doctorID + ", patientID=" + patientID + ", date=" + date + ", prix=" + prix
				+ "]";
	}

}
