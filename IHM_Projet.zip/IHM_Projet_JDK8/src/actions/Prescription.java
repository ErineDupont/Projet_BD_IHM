package actions;

import java.sql.Date;

import metier.Doctor;
import metier.Patient;

/** Représentation informatique d'une prescription
 */

public class Prescription {
	private int prescriptionID;
	private String medicament;
	private int doctorID;
	private int patientID;
	private Date date;
	private int duration;
	private float posology;
	private String modalities;

	public Prescription (int prescriptionID, String medicament, 
			int doctorID, int patientID, Date date, int duration, 
			float posology, String modalities) 
	{
		this.prescriptionID = prescriptionID;
		this.medicament = medicament;
		this.doctorID = doctorID;
		this.patientID = patientID;
		this.date = date;
		this.duration = duration;
		this.posology = posology;
		this.modalities = modalities;
	}
	
	public Prescription (int prescriptionID, String medicament,
			Doctor doctor, Patient patient, Date date, int duration, 
			float posology, String modalities)
	{
		this.prescriptionID = prescriptionID;
		this.medicament = medicament;
		this.doctorID = doctor.getDoctorID();
		this.patientID = patient.getPatientID();
		this.date = date;
		this.duration = duration;
		this.posology = posology;
		this.modalities = modalities;
	}
	
	public Prescription (int prescriptionID, String medicament, Consultation consultation, 
			int duration, float posology, String modalities) {
		this.prescriptionID = prescriptionID;
		this.medicament = medicament;
		this.doctorID = consultation.getDoctorID();
		this.patientID = consultation.getPatientID();
		this.date = consultation.getDate();
		this.duration = duration;
		this.posology = posology;
		this.modalities = modalities;
	}
	
	public int getPrescriptionID() {
		return prescriptionID;
	}

	public void setPrescriptionID(int prescriptionID) {
		this.prescriptionID = prescriptionID;
	}

	public String getMedicament() {
		return medicament;
	}

	public void setMedicament(String medicament) {
		this.medicament = medicament;
	}

	public int getDoctorID() {
		return doctorID;
	}

	public void setDoctorID(int doctorID) {
		this.doctorID = doctorID;
	}

	public int getPatientID() {
		return patientID;
	}

	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public float getPosology() {
		return posology;
	}

	public void setPosology(float posology) {
		this.posology = posology;
	}

	public String getModalities() {
		return modalities;
	}

	public void setModalities(String modalities) {
		this.modalities = modalities;
	}

	@Override
	public String toString() {
		return "Prescription [prescriptionID=" + prescriptionID + ", medicament=" + medicament + ", doctorID="
				+ doctorID + ", patientID=" + patientID + ", date=" + date + ", duration=" + duration + ", posology="
				+ posology + ", modalities=" + modalities + "]";
	}
	
	
}

