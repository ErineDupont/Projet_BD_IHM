package actions;


import java.util.List;
import metier.Doctor;
import metier.Patient;

/** Représentation informatique d'un acte médical
 */

public class MedicalAct {
	
	private int actID;
	private int doctorID;
	private int patientID;
	private String type;
	private List<Doctor> staff;

	public MedicalAct(int actID, int doctorID, int patientID, String type, List<Doctor> staff) {
		this.actID = actID;
		this.doctorID = doctorID;
		this.patientID = patientID;
		this.type = type;
		this.staff = staff;
	}
	
	public MedicalAct(int actID, Doctor doctor, Patient patient, String type, List<Doctor> staff) {
		this.actID = actID;
		this.doctorID = doctor.getDoctorID();
		this.patientID = patient.getPatientID();
		this.type = type;
		this.staff = staff;
	}

	public int getActID() {
		return actID;
	}

	public void setActID(int actID) {
		this.actID = actID;
	}

	public int getDoctorID() {
		return doctorID;
	}

	public void setDoctorID(int doctorID) {
		this.doctorID = doctorID;
	}

	public int getPatientID() {
		return patientID;
	}

	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Doctor> getStaff() {
		return staff;
	}

	public void setStaff(List<Doctor> staff) {
		this.staff = staff;
	}

	@Override
	public String toString() {
		return "MedicalAct [actID=" + actID + ", doctorID=" + doctorID + ", patientID=" + patientID + ", type=" + type
				+ ", staff=" + staff + "]";
	}
	
	
}
